package h4bit.h4bit;

import java.util.Date;

/**
 * Created by James on 2017-10-20.
 */

public class Follow {

    private Date date;
    private String followed;
    private String follower;
    private Boolean requested;

    public void acceptRequest(){

    }
}
