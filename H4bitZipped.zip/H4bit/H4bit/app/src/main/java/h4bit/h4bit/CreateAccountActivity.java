package h4bit.h4bit;

/**
 * Created by benhl on 2017-10-29.
 */

/**
 * usernameText, passwordText, signupButton, crealogButton
 * These are the respective textboxes required to handle the information
 * we plan for this screen to have dual functionality, so the crealog button should
 * either show create or login depending on whether they are
 * creating an account or logging in with an existing account
 */

public class CreateAccountActivity {
}
